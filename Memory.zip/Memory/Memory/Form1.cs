﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Memory
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        int[] pictureOrderIndex = new int[20];

        bool ifAnyClicked = false;
        bool[] ifPicture = new bool[11];
        bool[] ifPictureO = new bool[11];
        bool ifPrevented = false;

        int whichOneWasLastShowed = 0;

        private void WaitNSeconds(int segundos)
        {
            if (segundos < 1) return;
            DateTime _desired = DateTime.Now.AddSeconds(segundos);
            while (DateTime.Now < _desired)
            {
                System.Windows.Forms.Application.DoEvents();
            }
        }

        private void shuffle(int whichOne)
        {

            bool wasBefore=false;
            int x = 0;

            
            do
            {
                Random pictureOrder = new Random();
                x = pictureOrder.Next(1, 21);
                
                for (int i = 1; i < whichOne+1; i++)
                {
                    if (x == pictureOrderIndex[i-1])
                    {
                        wasBefore = true;
                        break;
                    }
                    wasBefore = false;
                }

            } while (wasBefore == true);

            pictureOrderIndex[whichOne] = x;
        }

        private Tuple<int, int> positioning(int input)
        {
            int x=0, y=0;
            switch (input)
            {
                case 1:
                    x = 12;
                    y = 62;
                    break;
                case 2:
                    x = 98;
                    y = 62;
                    break;
                case 3:
                    x = 184;
                    y = 62;
                    break;
                case 4:
                    x = 270;
                    y = 62;
                    break;
                case 5:
                    x = 356;
                    y = 62;
                    break;
                case 6:
                    x = 12;
                    y = 148;
                    break;
                case 7:
                    x = 98;
                    y = 148;
                    break;
                case 8:
                    x = 184;
                    y = 148;
                    break;
                case 9:
                    x = 270;
                    y = 148;
                    break;
                case 10:
                    x = 356;
                    y = 148;
                    break;
                case 11:
                    x = 12;
                    y = 234;
                    break;
                case 12:
                    x = 98;
                    y = 234;
                    break;
                case 13:
                    x = 184;
                    y = 234;
                    break;
                case 14:
                    x = 270;
                    y = 234;
                    break;
                case 15:
                    x = 356;
                    y = 234;
                    break;
                case 16:
                    x = 12;
                    y = 320;
                    break;
                case 17:
                    x = 98;
                    y = 320;
                    break;
                case 18:
                    x = 184;
                    y = 320;
                    break;
                case 19:
                    x = 270;
                    y = 320;
                    break;
                case 20:
                    x = 356;
                    y = 320;
                    break;
                default:
                    x = 10;
                    y = 55;
                    break;
            }
            return Tuple.Create(x, y);
        }

        private void check(int i)
        {
            if (ifPicture[i] == false)
            {
                if (ifAnyClicked == false)
                {
                    ifPicture[i] = true;
                    string myPath = Application.StartupPath + "\\images\\"+i.ToString()+".jpg";
                    switch(i)
                    {
                        case 1:
                            pictureBox1.Image = new Bitmap(myPath);
                            break;
                        case 2:
                            pictureBox2.Image = new Bitmap(myPath);
                            break;
                        case 3:
                            pictureBox3.Image = new Bitmap(myPath);
                            break;
                        case 4:
                            pictureBox4.Image = new Bitmap(myPath);
                            break;
                        case 5:
                            pictureBox5.Image = new Bitmap(myPath);
                            break;
                        case 6:
                            pictureBox6.Image = new Bitmap(myPath);
                            break;
                        case 7:
                            pictureBox7.Image = new Bitmap(myPath);
                            break;
                        case 8:
                            pictureBox8.Image = new Bitmap(myPath);
                            break;
                        case 9:
                            pictureBox9.Image = new Bitmap(myPath);
                            break;
                        case 10:
                            pictureBox10.Image = new Bitmap(myPath);
                            break;
                    }
                    ifAnyClicked = true;
                }
                else
                {
                    ifPicture[i] = true;

                    string myPath = Application.StartupPath + "\\images\\" + i.ToString() +".jpg";
                    switch(i)
                    {
                        case 1:
                            pictureBox1.Image = new Bitmap(myPath);
                            break;
                        case 2:
                            pictureBox2.Image = new Bitmap(myPath);
                            break;
                        case 3:
                            pictureBox3.Image = new Bitmap(myPath);
                            break;
                        case 4:
                            pictureBox4.Image = new Bitmap(myPath);
                            break;
                        case 5:
                            pictureBox5.Image = new Bitmap(myPath);
                            break;
                        case 6:
                            pictureBox6.Image = new Bitmap(myPath);
                            break;
                        case 7:
                            pictureBox7.Image = new Bitmap(myPath);
                            break;
                        case 8:
                            pictureBox8.Image = new Bitmap(myPath);
                            break;
                        case 9:
                            pictureBox9.Image = new Bitmap(myPath);
                            break;
                        case 10:
                            pictureBox10.Image = new Bitmap(myPath);
                            break;
                        case 11:
                            pictureBox11.Image = new Bitmap(myPath);
                            break;
                        case 12:
                            pictureBox12.Image = new Bitmap(myPath);
                            break;
                        case 13:
                            pictureBox13.Image = new Bitmap(myPath);
                            break;
                        case 14:
                            pictureBox14.Image = new Bitmap(myPath);
                            break;
                        case 15:
                            pictureBox15.Image = new Bitmap(myPath);
                            break;
                        case 16:
                            pictureBox16.Image = new Bitmap(myPath);
                            break;
                        case 17:
                            pictureBox17.Image = new Bitmap(myPath);
                            break;
                        case 18:
                            pictureBox18.Image = new Bitmap(myPath);
                            break;
                        case 19:
                            pictureBox19.Image = new Bitmap(myPath);
                            break;
                        case 20:
                            pictureBox20.Image = new Bitmap(myPath);
                            break;
                    }

                    if (ifPictureO[i] == false)
                    {
                        ifPrevented = true;
                        WaitNSeconds(1);
                        ifPicture[i] = false;
                        if (whichOneWasLastShowed > 10)
                            ifPictureO[whichOneWasLastShowed - 10] = false;
                        else
                            ifPicture[whichOneWasLastShowed] = false;

                        string myPath2 = Application.StartupPath + "\\images\\memory.png";
                        switch (i)
                        {
                            case 1:
                                pictureBox1.Image = new Bitmap(myPath2);
                                break;
                            case 2:
                                pictureBox2.Image = new Bitmap(myPath2);
                                break;
                            case 3:
                                pictureBox3.Image = new Bitmap(myPath2);
                                break;
                            case 4:
                                pictureBox4.Image = new Bitmap(myPath2);
                                break;
                            case 5:
                                pictureBox5.Image = new Bitmap(myPath2);
                                break;
                            case 6:
                                pictureBox6.Image = new Bitmap(myPath2);
                                break;
                            case 7:
                                pictureBox7.Image = new Bitmap(myPath2);
                                break;
                            case 8:
                                pictureBox8.Image = new Bitmap(myPath2);
                                break;
                            case 9:
                                pictureBox9.Image = new Bitmap(myPath2);
                                break;
                            case 10:
                                pictureBox10.Image = new Bitmap(myPath2);
                                break;
                        }
                        
                        switch (whichOneWasLastShowed)
                        {
                            case 1:
                                pictureBox1.Image = new Bitmap(myPath2);
                                break;
                            case 2:
                                pictureBox2.Image = new Bitmap(myPath2);
                                break;
                            case 3:
                                pictureBox3.Image = new Bitmap(myPath2);
                                break;
                            case 4:
                                pictureBox4.Image = new Bitmap(myPath2);
                                break;
                            case 5:
                                pictureBox5.Image = new Bitmap(myPath2);
                                break;
                            case 6:
                                pictureBox6.Image = new Bitmap(myPath2);
                                break;
                            case 7:
                                pictureBox7.Image = new Bitmap(myPath2);
                                break;
                            case 8:
                                pictureBox8.Image = new Bitmap(myPath2);
                                break;
                            case 9:
                                pictureBox9.Image = new Bitmap(myPath2);
                                break;
                            case 10:
                                pictureBox10.Image = new Bitmap(myPath2);
                                break;
                            case 11:
                                pictureBox11.Image = new Bitmap(myPath2);
                                break;
                            case 12:
                                pictureBox12.Image = new Bitmap(myPath2);
                                break;
                            case 13:
                                pictureBox13.Image = new Bitmap(myPath2);
                                break;
                            case 14:
                                pictureBox14.Image = new Bitmap(myPath2);
                                break;
                            case 15:
                                pictureBox15.Image = new Bitmap(myPath2);
                                break;
                            case 16:
                                pictureBox16.Image = new Bitmap(myPath2);
                                break;
                            case 17:
                                pictureBox17.Image = new Bitmap(myPath2);
                                break;
                            case 18:
                                pictureBox18.Image = new Bitmap(myPath2);
                                break;
                            case 19:
                                pictureBox19.Image = new Bitmap(myPath2);
                                break;
                            case 20:
                                pictureBox20.Image = new Bitmap(myPath2);
                                break;
                        }
                        ifPrevented = false;
                    }
                    ifAnyClicked = false;
                }
                whichOneWasLastShowed = i;
            }
        }

        private void checkO(int i)
        {
            if (ifPictureO[i] == false)
            {
                if (ifAnyClicked == false)
                {
                    ifPictureO[i] = true;
                    string myPath = Application.StartupPath + "\\images\\" + i.ToString() + ".jpg";
                    switch (i)
                    {
                        case 1:
                            pictureBox11.Image = new Bitmap(myPath);
                            break;
                        case 2:
                            pictureBox12.Image = new Bitmap(myPath);
                            break;
                        case 3:
                            pictureBox13.Image = new Bitmap(myPath);
                            break;
                        case 4:
                            pictureBox14.Image = new Bitmap(myPath);
                            break;
                        case 5:
                            pictureBox15.Image = new Bitmap(myPath);
                            break;
                        case 6:
                            pictureBox16.Image = new Bitmap(myPath);
                            break;
                        case 7:
                            pictureBox17.Image = new Bitmap(myPath);
                            break;
                        case 8:
                            pictureBox18.Image = new Bitmap(myPath);
                            break;
                        case 9:
                            pictureBox19.Image = new Bitmap(myPath);
                            break;
                        case 10:
                            pictureBox20.Image = new Bitmap(myPath);
                            break;
                    }
                    ifAnyClicked = true;
                }
                else
                {
                    ifPictureO[i] = true;
                    string myPath = Application.StartupPath + "\\images\\" + i.ToString() + ".jpg";
                    switch (i)
                    {
                        case 1:
                            pictureBox11.Image = new Bitmap(myPath);
                            break;
                        case 2:
                            pictureBox12.Image = new Bitmap(myPath);
                            break;
                        case 3:
                            pictureBox13.Image = new Bitmap(myPath);
                            break;
                        case 4:
                            pictureBox14.Image = new Bitmap(myPath);
                            break;
                        case 5:
                            pictureBox15.Image = new Bitmap(myPath);
                            break;
                        case 6:
                            pictureBox16.Image = new Bitmap(myPath);
                            break;
                        case 7:
                            pictureBox17.Image = new Bitmap(myPath);
                            break;
                        case 8:
                            pictureBox18.Image = new Bitmap(myPath);
                            break;
                        case 9:
                            pictureBox19.Image = new Bitmap(myPath);
                            break;
                        case 10:
                            pictureBox20.Image = new Bitmap(myPath);
                            break;
                        case 11:
                            pictureBox11.Image = new Bitmap(myPath);
                            break;
                        case 12:
                            pictureBox12.Image = new Bitmap(myPath);
                            break;
                        case 13:
                            pictureBox13.Image = new Bitmap(myPath);
                            break;
                        case 14:
                            pictureBox14.Image = new Bitmap(myPath);
                            break;
                        case 15:
                            pictureBox15.Image = new Bitmap(myPath);
                            break;
                        case 16:
                            pictureBox16.Image = new Bitmap(myPath);
                            break;
                        case 17:
                            pictureBox17.Image = new Bitmap(myPath);
                            break;
                        case 18:
                            pictureBox18.Image = new Bitmap(myPath);
                            break;
                        case 19:
                            pictureBox19.Image = new Bitmap(myPath);
                            break;
                        case 20:
                            pictureBox20.Image = new Bitmap(myPath);
                            break;
                    }

                    
                    if (ifPicture[i] == false)
                    {
                        WaitNSeconds(1);
                        ifPictureO[i] = false;
                        if (whichOneWasLastShowed > 10)
                            ifPictureO[whichOneWasLastShowed - 10] = false;
                        else
                            ifPicture[whichOneWasLastShowed] = false;

                        string myPath2 = Application.StartupPath + "\\images\\memory.png";
                        switch (i)
                        {
                            case 1:
                                pictureBox11.Image = new Bitmap(myPath2);
                                break;
                            case 2:
                                pictureBox12.Image = new Bitmap(myPath2);
                                break;
                            case 3:
                                pictureBox13.Image = new Bitmap(myPath2);
                                break;
                            case 4:
                                pictureBox14.Image = new Bitmap(myPath2);
                                break;
                            case 5:
                                pictureBox15.Image = new Bitmap(myPath2);
                                break;
                            case 6:
                                pictureBox16.Image = new Bitmap(myPath2);
                                break;
                            case 7:
                                pictureBox17.Image = new Bitmap(myPath2);
                                break;
                            case 8:
                                pictureBox18.Image = new Bitmap(myPath2);
                                break;
                            case 9:
                                pictureBox19.Image = new Bitmap(myPath2);
                                break;
                            case 10:
                                pictureBox20.Image = new Bitmap(myPath2);
                                break;
                        }

                        switch (whichOneWasLastShowed)
                        {
                            case 1:
                                pictureBox1.Image = new Bitmap(myPath2);
                                break;
                            case 2:
                                pictureBox2.Image = new Bitmap(myPath2);
                                break;
                            case 3:
                                pictureBox3.Image = new Bitmap(myPath2);
                                break;
                            case 4:
                                pictureBox4.Image = new Bitmap(myPath2);
                                break;
                            case 5:
                                pictureBox5.Image = new Bitmap(myPath2);
                                break;
                            case 6:
                                pictureBox6.Image = new Bitmap(myPath2);
                                break;
                            case 7:
                                pictureBox7.Image = new Bitmap(myPath2);
                                break;
                            case 8:
                                pictureBox8.Image = new Bitmap(myPath2);
                                break;
                            case 9:
                                pictureBox9.Image = new Bitmap(myPath2);
                                break;
                            case 10:
                                pictureBox10.Image = new Bitmap(myPath2);
                                break;
                            case 11:
                                pictureBox11.Image = new Bitmap(myPath2);
                                break;
                            case 12:
                                pictureBox12.Image = new Bitmap(myPath2);
                                break;
                            case 13:
                                pictureBox13.Image = new Bitmap(myPath2);
                                break;
                            case 14:
                                pictureBox14.Image = new Bitmap(myPath2);
                                break;
                            case 15:
                                pictureBox15.Image = new Bitmap(myPath2);
                                break;
                            case 16:
                                pictureBox16.Image = new Bitmap(myPath2);
                                break;
                            case 17:
                                pictureBox17.Image = new Bitmap(myPath2);
                                break;
                            case 18:
                                pictureBox18.Image = new Bitmap(myPath2);
                                break;
                            case 19:
                                pictureBox19.Image = new Bitmap(myPath2);
                                break;
                            case 20:
                                pictureBox20.Image = new Bitmap(myPath2);
                                break;
                        }
                    }
                    ifAnyClicked = false;

                }
                whichOneWasLastShowed = i+10;
            }
        }

        private void win()
        {
            if (ifPicture[1] && ifPicture[2] && ifPicture[3] && ifPicture[4] && ifPicture[5] && ifPicture[6] && ifPicture[7] && ifPicture[8] && ifPicture[9] && ifPicture[10] && ifPictureO[1] && ifPictureO[2] && ifPictureO[3] && ifPictureO[4] && ifPictureO[5] && ifPictureO[6] && ifPictureO[7] && ifPictureO[8] && ifPictureO[9] && ifPictureO[10] == true)
            {
                MessageBox.Show("Wygrana!");
                this.Controls.Clear();
                this.InitializeComponent();
                for (int i = 1; i <= 10; i++)
                {
                    ifPicture[i] = false;
                    ifPictureO[i] = false;
                }

                Random pictureOrder = new Random();
                int x = pictureOrder.Next(1, 21);
                pictureOrderIndex[0] = x;
                Point position = new Point(positioning(pictureOrderIndex[0]).Item1, positioning(pictureOrderIndex[0]).Item2);
                pictureBox1.Location = position;
                for (int i = 1; i < 20; i++)
                {
                    shuffle(i);
                    Point positionFor = new Point(positioning(pictureOrderIndex[i]).Item1, positioning(pictureOrderIndex[i]).Item2);
                    switch (i + 1)
                    {
                        case 2:
                            pictureBox2.Location = positionFor;
                            break;
                        case 3:
                            pictureBox3.Location = positionFor;
                            break;
                        case 4:
                            pictureBox4.Location = positionFor;
                            break;
                        case 5:
                            pictureBox5.Location = positionFor;
                            break;
                        case 6:
                            pictureBox6.Location = positionFor;
                            break;
                        case 7:
                            pictureBox7.Location = positionFor;
                            break;
                        case 8:
                            pictureBox8.Location = positionFor;
                            break;
                        case 9:
                            pictureBox9.Location = positionFor;
                            break;
                        case 10:
                            pictureBox10.Location = positionFor;
                            break;
                        case 11:
                            pictureBox11.Location = positionFor;
                            break;
                        case 12:
                            pictureBox12.Location = positionFor;
                            break;
                        case 13:
                            pictureBox13.Location = positionFor;
                            break;
                        case 14:
                            pictureBox14.Location = positionFor;
                            break;
                        case 15:
                            pictureBox15.Location = positionFor;
                            break;
                        case 16:
                            pictureBox16.Location = positionFor;
                            break;
                        case 17:
                            pictureBox17.Location = positionFor;
                            break;
                        case 18:
                            pictureBox18.Location = positionFor;
                            break;
                        case 19:
                            pictureBox19.Location = positionFor;
                            break;
                        case 20:
                            pictureBox20.Location = positionFor;
                            break;
                    }
                }
            }
                
        }


        private void pictureBox1_Click(object sender, EventArgs e)
        {
            if (ifPrevented == false)
            {
                string myPath = Application.StartupPath + "\\images\\1.jpg";
                pictureBox1.Image = new Bitmap(myPath);
                check(1);
                win();
            }
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            for(int i=1; i<=10; i++)
            {
                ifPicture[i] = false;
                ifPictureO[i] = false;
            }

            Random pictureOrder = new Random();
            int x = pictureOrder.Next(1, 21);
            pictureOrderIndex[0] = x;
            Point position = new Point(positioning(pictureOrderIndex[0]).Item1, positioning(pictureOrderIndex[0]).Item2);
            pictureBox1.Location = position;
            for (int i = 1; i < 20; i++)
            {
                shuffle(i);
                Point positionFor = new Point(positioning(pictureOrderIndex[i]).Item1, positioning(pictureOrderIndex[i]).Item2);
                switch (i+1)
                {
                    case 2:
                        pictureBox2.Location = positionFor;
                        break;
                    case 3:
                        pictureBox3.Location = positionFor;
                        break;
                    case 4:
                        pictureBox4.Location = positionFor;
                        break;
                    case 5:
                        pictureBox5.Location = positionFor;
                        break;
                    case 6:
                        pictureBox6.Location = positionFor;
                        break;
                    case 7:
                        pictureBox7.Location = positionFor;
                        break;
                    case 8:
                        pictureBox8.Location = positionFor;
                        break;
                    case 9:
                        pictureBox9.Location = positionFor;
                        break;
                    case 10:
                        pictureBox10.Location = positionFor;
                        break;
                    case 11:
                        pictureBox11.Location = positionFor;
                        break;
                    case 12:
                        pictureBox12.Location = positionFor;
                        break;
                    case 13:
                        pictureBox13.Location = positionFor;
                        break;
                    case 14:
                        pictureBox14.Location = positionFor;
                        break;
                    case 15:
                        pictureBox15.Location = positionFor;
                        break;
                    case 16:
                        pictureBox16.Location = positionFor;
                        break;
                    case 17:
                        pictureBox17.Location = positionFor;
                        break;
                    case 18:
                        pictureBox18.Location = positionFor;
                        break;
                    case 19:
                        pictureBox19.Location = positionFor;
                        break;
                    case 20:
                        pictureBox20.Location = positionFor;
                        break;
                }
            }
            
        }

        private void Form1_Click(object sender, EventArgs e)
        {
            /*string x = "";
            for (int i = 0; i < 20; i++)
                x += Convert.ToString(pictureOrderIndex[i]) + " ";
            x += '\n' + ifAnyClicked.ToString() + '\n' + whichOneWasLastShowed;
            MessageBox.Show(x);
            */
        }

        private void pictureBox20_Click(object sender, EventArgs e)
        {
            if (ifPrevented == false)
            {
                string myPath = Application.StartupPath + "\\images\\10.jpg";
                pictureBox20.Image = new Bitmap(myPath);
                checkO(10);
                win();
            }
        }

        private void pictureBox15_Click(object sender, EventArgs e)
        {
            if (ifPrevented == false)
            {
                string myPath = Application.StartupPath + "\\images\\5.jpg";
                pictureBox15.Image = new Bitmap(myPath);
                checkO(5);
                win();
            }
        }

        private void pictureBox10_Click(object sender, EventArgs e)
        {
            if (ifPrevented == false)
            {
                string myPath = Application.StartupPath + "\\images\\10.jpg";
                pictureBox10.Image = new Bitmap(myPath);
                check(10);
                win();
            }
        }

        private void pictureBox5_Click(object sender, EventArgs e)
        {
            if (ifPrevented == false)
            {
                string myPath = Application.StartupPath + "\\images\\5.jpg";
                pictureBox5.Image = new Bitmap(myPath);
                check(5);
                win();
            }
        }

        private void pictureBox19_Click(object sender, EventArgs e)
        {
            if (ifPrevented == false)
            {
                string myPath = Application.StartupPath + "\\images\\9.jpg";
                pictureBox19.Image = new Bitmap(myPath);
                checkO(9);
                win();
            }
        }

        private void pictureBox14_Click(object sender, EventArgs e)
        {
            if (ifPrevented == false)
            {
                string myPath = Application.StartupPath + "\\images\\4.jpg";
                pictureBox14.Image = new Bitmap(myPath);
                checkO(4);
                win();
            }
        }

        private void pictureBox9_Click(object sender, EventArgs e)
        {
            if (ifPrevented == false)
            {
                string myPath = Application.StartupPath + "\\images\\9.jpg";
                pictureBox9.Image = new Bitmap(myPath);
                check(9);
                win();
            }
        }

        private void pictureBox4_Click(object sender, EventArgs e)
        {
            if (ifPrevented == false)
            {
                string myPath = Application.StartupPath + "\\images\\4.jpg";
                pictureBox4.Image = new Bitmap(myPath);
                check(4);
                win();
            }
        }

        private void pictureBox18_Click(object sender, EventArgs e)
        {
            if (ifPrevented == false)
            {
                string myPath = Application.StartupPath + "\\images\\8.jpg";
                pictureBox18.Image = new Bitmap(myPath);
                checkO(8);
                win();
            }
        }

        private void pictureBox13_Click(object sender, EventArgs e)
        {
            if (ifPrevented == false)
            {
                string myPath = Application.StartupPath + "\\images\\3.jpg";
                pictureBox13.Image = new Bitmap(myPath);
                checkO(3);
                win();
            }
        }

        private void pictureBox8_Click(object sender, EventArgs e)
        {
            if (ifPrevented == false)
            {
                string myPath = Application.StartupPath + "\\images\\8.jpg";
                pictureBox8.Image = new Bitmap(myPath);
                check(8);
                win();
            }
        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {
            if (ifPrevented == false)
            {
                string myPath = Application.StartupPath + "\\images\\2.jpg";
                pictureBox2.Image = new Bitmap(myPath);
                check(2);
                win();
            }
        }

        private void pictureBox17_Click(object sender, EventArgs e)
        {
            if (ifPrevented == false)
            {
                string myPath = Application.StartupPath + "\\images\\7.jpg";
                pictureBox17.Image = new Bitmap(myPath);
                checkO(7);
                win();
            }
        }

        private void pictureBox12_Click(object sender, EventArgs e)
        {
            if (ifPrevented == false)
            {
                string myPath = Application.StartupPath + "\\images\\2.jpg";
                pictureBox12.Image = new Bitmap(myPath);
                checkO(2);
                win();
            }
        }

        private void pictureBox7_Click(object sender, EventArgs e)
        {
            if (ifPrevented == false)
            {
                string myPath = Application.StartupPath + "\\images\\7.jpg";
                pictureBox7.Image = new Bitmap(myPath);
                check(7);
                win();
            }
        }

        private void pictureBox3_Click(object sender, EventArgs e)
        {
            if (ifPrevented == false)
            {
                string myPath = Application.StartupPath + "\\images\\3.jpg";
                pictureBox3.Image = new Bitmap(myPath);
                check(3);
                win();
            }
        }

        private void pictureBox16_Click(object sender, EventArgs e)
        {
            if (ifPrevented == false)
            {
                string myPath = Application.StartupPath + "\\images\\6.jpg";
                pictureBox16.Image = new Bitmap(myPath);
                checkO(6);
                win();
            }
        }

        private void pictureBox11_Click(object sender, EventArgs e)
        {
            if (ifPrevented == false)
            {
                string myPath = Application.StartupPath + "\\images\\1.jpg";
                pictureBox11.Image = new Bitmap(myPath);
                checkO(1);
                win();
            }
        }

        private void pictureBox6_Click(object sender, EventArgs e)
        {
            if (ifPrevented == false)
            {
                string myPath = Application.StartupPath + "\\images\\6.jpg";
                pictureBox6.Image = new Bitmap(myPath);
                check(6);
                win();
            }
        }
    }
}
